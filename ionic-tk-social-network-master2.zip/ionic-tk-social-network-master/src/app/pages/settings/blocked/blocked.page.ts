import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocked',
  templateUrl: './blocked.page.html',
  styleUrls: ['./blocked.page.scss'],
})
export class BlockedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
