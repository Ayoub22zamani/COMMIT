import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interesting-posts',
  templateUrl: './interesting-posts.component.html',
  styleUrls: ['./interesting-posts.component.scss'],
})
export class InterestingPostsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
