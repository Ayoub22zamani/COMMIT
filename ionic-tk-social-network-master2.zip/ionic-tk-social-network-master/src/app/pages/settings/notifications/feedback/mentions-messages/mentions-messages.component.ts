import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentions-messages',
  templateUrl: './mentions-messages.component.html',
  styleUrls: ['./mentions-messages.component.scss'],
})
export class MentionsMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
