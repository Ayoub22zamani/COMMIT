import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participation-polls',
  templateUrl: './participation-polls.component.html',
  styleUrls: ['./participation-polls.component.scss'],
})
export class ParticipationPollsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
