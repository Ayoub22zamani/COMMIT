import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-story-replies',
  templateUrl: './story-replies.component.html',
  styleUrls: ['./story-replies.component.scss'],
})
export class StoryRepliesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
