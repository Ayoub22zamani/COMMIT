import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-messages',
  templateUrl: './community-messages.component.html',
  styleUrls: ['./community-messages.component.scss'],
})
export class CommunityMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
