import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closed-community-posts',
  templateUrl: './closed-community-posts.component.html',
  styleUrls: ['./closed-community-posts.component.scss'],
})
export class ClosedCommunityPostsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
