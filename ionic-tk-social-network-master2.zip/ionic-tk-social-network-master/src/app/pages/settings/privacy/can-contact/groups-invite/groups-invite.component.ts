import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-groups-invite',
  templateUrl: './groups-invite.component.html',
  styleUrls: ['./groups-invite.component.scss'],
})
export class GroupsInviteComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
