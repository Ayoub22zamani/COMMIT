import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-send',
  templateUrl: './mail-send.component.html',
  styleUrls: ['./mail-send.component.scss'],
})
export class MailSendComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
