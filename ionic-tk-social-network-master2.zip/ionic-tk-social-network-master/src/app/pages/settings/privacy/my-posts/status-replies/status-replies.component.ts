import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-status-replies',
  templateUrl: './status-replies.component.html',
  styleUrls: ['./status-replies.component.scss'],
})
export class StatusRepliesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
