import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wall-send',
  templateUrl: './wall-send.component.html',
  styleUrls: ['./wall-send.component.scss'],
})
export class WallSendComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
