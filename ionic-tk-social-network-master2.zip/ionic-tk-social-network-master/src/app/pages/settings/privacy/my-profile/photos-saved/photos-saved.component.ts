import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photos-saved',
  templateUrl: './photos-saved.component.html',
  styleUrls: ['./photos-saved.component.scss'],
})
export class PhotosSavedComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
