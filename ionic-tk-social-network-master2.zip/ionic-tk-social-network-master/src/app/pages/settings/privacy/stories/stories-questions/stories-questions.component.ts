import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stories-questions',
  templateUrl: './stories-questions.component.html',
  styleUrls: ['./stories-questions.component.scss'],
})
export class StoriesQuestionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
