import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stories-replies',
  templateUrl: './stories-replies.component.html',
  styleUrls: ['./stories-replies.component.scss'],
})
export class StoriesRepliesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
